<?= $this->extend('admin/template'); ?>

<?= $this->section('main'); ?>

<h2 class="mb-5">Daftar INFOKUS</h2>

<div class="mb-3">
    <a href="<?= base_url('admin/daftar-infokus/tambah')?>" class="btn btn-primary">Tambah INFOKUS</a>
</div>

<div class="mb-5">
    <table class="table table-stripped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nama INFOKUS</th>
                <th scope="col">Merek</th>
                <th scope="col">Spesifikasi</th>
                <th scope="col">Tahun Rilis</th>
                <th scope="col">Gambar</th>
                <th scope="col">Harga</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($infocuss as $infokus):?>
            <tr>
                <th scope="row"><?=$infokus['id']?></th>
                <td><?= $infokus['nama']?></td>
                <td><?= $infokus['merek']?></td>
                <td><?= $infokus['spesifikasi']?></td>
                <td><?= $infokus['tahun_rilis']?></td>
                <td>
                    <img src="<?= base_url($infokus['gambar'])?>" alt="" style="width: 150px; height: auto;">
                </td>
                <td><?= $infokus['harga']?></td>
                <td>
                    <a href="<?= base_url('admin/daftar-infokus/edit')?>/<?=$infokus['id']?>"class="btn btn-success">Edit</a>
                    <a href="<?= base_url('admin/daftar-infokus/hapus')?>/<?=$infokus['id']?>"class="btn btn-danger">Hapus</a>
                </td>
            </tr>
            <?php endforeach?>
        </tbody>
    </table>
</div>

<?= $this->endSection();?>
