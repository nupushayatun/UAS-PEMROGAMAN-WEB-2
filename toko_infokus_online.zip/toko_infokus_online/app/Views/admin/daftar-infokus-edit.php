<?= $this->extend('admin/template') ?>
<?= $this->section('main') ?>
<h2 class="mb-5">Edit INFOKUS</h2>
<form action="<?= base_url('admin/daftar-infokus/change') ?>" method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= $infokus['id']; ?>">
    <input type="hidden" name="gambar_lama" value="<?= $infokus['gambar']; ?>">
    
    <div class="mb-3">
        <label for="nama" class="form-label">Nama INFOKUS</label>
        <input type="text" class="form-control w-50" id="nama" 
            placeholder="nama" name="nama" value="<?= $infokus['nama']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <label for="merek" class="form-label">Merek</label>
        <input type="text" class="form-control" id="merek" name="merek" value="<?= $infokus['merek']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <label for="spesifikasi" class="form-label">Spesifikasi</label>
        <textarea class="form-control" id="spesifikasi" name="spesifikasi" 
            autocomplete="off" required><?= $infokus['spesifikasi']; ?></textarea>
    </div>
    <div class="mb-3">
        <label for="tahun_rilis" class="form-label">Tahun Rilis</label>
        <input type="number" class="form-control" id="tahun_rilis" name="tahun_rilis" value="<?= $infokus['tahun_rilis']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <label for="gambar" class="form-label">Gambar INFOKUS</label>
        <input type="file" class="form-control" id="gambar" name="gambar" autocomplete="off">
        <small>Gambar saat ini: <?= $infokus['gambar']; ?></small>
    </div>
    <div class="mb-3">
        <label for="harga" class="form-label">Harga</label>
        <input type="number" class="form-control" id="harga" name="harga" value="<?= $infokus['harga']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <a href="<?= base_url('admin/daftar-infokus') ?>" class="btn btn-secondary">Kembali</a>
        <button type="submit" class="btn btn-primary">Ubah</button>
    </div>
</form>
<?= $this->endSection() ?>