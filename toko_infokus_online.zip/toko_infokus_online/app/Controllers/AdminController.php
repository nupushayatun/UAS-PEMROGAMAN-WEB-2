<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\InfokusModel;
use CodeIgniter\HTTP\ResponseInterface;

class AdminController extends BaseController {
    public function index() {
        return view('admin/dashboard');
    }

    public function daftarInfokus() {
        $infokusModel = new InfokusModel();
        $data['infocuss'] = $infokusModel->findAll();
        return view('admin/daftar-infokus', $data);
    }

    public function daftarInfokusTambah() {
        return view('admin/daftar-infokus-tambah');
    }

    public function createInfokus() {
        $data = $this->request->getPost();
        $file = $this->request->getFile('gambar');

        if(!$file->hasMoved()) {
            $path = $file->store('images');
            $data['gambar'] = $path;
        }

        $infokusModel = new InfokusModel();

        if($infokusModel->insert($data,false)) {
            return redirect()->to('admin/daftar-infokus')->with('berhasil','data berhasil disimpan!');
        } else {
            return redirect()->to('admin/daftar-infokus')->with('gagal','data gagal disimpan!');
        }
    }

    public function daftarInfokusEdit($id) {
        $infokusModel = new InfokusModel();
        $data['infokus'] = $infokusModel->find($id);
        
        if ($data['infokus']) {
            return view('admin/daftar-infokus-edit', $data);
        }
        return redirect()->to('admin/daftar-infokus')->with('gagal', 'Data infokus tidak ditemukan.');
    }

    public function updateInfokus($id) {
        $infokusModel = new InfokusModel();
        $data = $this->request->getPost();
        
        // Handle image upload if new image is provided
        $file = $this->request->getFile('gambar');
        if ($file->isValid() && !$file->hasMoved()) {
            $path = $file->store('images');
            $data['gambar'] = $path;
        }

        if ($infokusModel->update($id, $data)) {
            return redirect()->to('admin/daftar-infokus')->with('berhasil', 'Data infokus berhasil diupdate!');
        }
        return redirect()->to('admin/daftar-infokus')->with('gagal', 'Data infokus gagal diupdate!');
    }

    public function hapusInfokus($id) {
        $infokusModel = new InfokusModel();
        $infokus = $infokusModel->find($id);

        if ($infokus) {
            $infokusModel->delete($id);
            return redirect()->to('/admin/daftar-infokus')->with('berhasil', 'Data infokus berhasil dihapus.');
        }
        return redirect()->to('/admin/daftar-infokus')->with('gagal', 'Data infokus tidak ditemukan.');
    }

    public function transaksi() {
        return view('admin/transaksi');
    }

    public function transaksiUbahStatus() {
        return view('admin/transaksi-ubah-status');
    }

    public function transaksiHapus() {
        return view('admin/transaksi-hapus');
    }

    public function pelanggan() {
        return view('admin/pelanggan');
    }

    public function pelangganHapus() {
        return view('admin/pelanggan-hapus');
    }
}